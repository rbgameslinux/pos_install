#!/bin/bash

# Verifica se há algum áudio sendo reproduzido
audio_playing=$(pactl list short sink-inputs | wc -l)

# Verifica se há algum processo de vídeo em execução (assumindo o uso de ffmpeg ou outros players)
video_playing=$(ps aux | grep -E 'ffmpeg|vlc|mpv|youtube-dl|stremio' | grep -v 'grep' | wc -l)

# Se houver áudio ou vídeo sendo reproduzido, não suspende
if [ "$audio_playing" -gt 0 ] || [ "$video_playing" -gt 0 ]; then
    echo "Mídia detectada, não suspendendo."
    exit 0
fi

# Caso contrário, suspende o sistema
echo "Sem mídia detectada, suspendendo o sistema."
systemctl suspend
