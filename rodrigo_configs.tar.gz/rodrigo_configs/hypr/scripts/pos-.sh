#!/bin/bash

#pós instalação

#wofi = programa de menu inspirado em rofi
#rofi = alternador de janelas, executa diálogos
#waybar = barra de tarefas personalizavel
#swww =  backend de p/papel de parede
#dolphin-plugind = adicionais p/o dolphin
#swaync = notificações obs(desinstalar o dunst) dunst é a notificação padrão do wayprland

sudo pacman -R dunst ; sudo pacman -S wofi rofi waybar swww dolphin-plugins swaync   

