#!/bin/bash

# Configurações
DISK_MAIN="/"
DISK_TOOL="gnome-disks"  # Substitua pelo utilitário de disco de sua preferência

# Obter o uso do disco principal
DISK_USAGE=$(df -h "$DISK_MAIN" | awk 'NR==2 {print $5}')

# Obter detalhes de todos os discos
DISK_DETAILS=$(lsblk -o NAME,SIZE,TYPE,MOUNTPOINT | awk '
    BEGIN {printf "Name       Size    Type   Mountpoint\n-----------------------------------\n"}
    $1 !~ /loop/ && $3 == "disk" || $3 == "part" {printf "%-10s %-8s %-6s %s\n", $1, $2, $3, $4}
')

# Gerar saída para a Waybar
echo " $DISK_USAGE"  # Ícone + uso do disco principal
echo "$DISK_DETAILS"  # Tooltip com detalhes
