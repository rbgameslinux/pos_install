#!/usr/bin/env bash

# Arquivos temporários
updates_file="/tmp/waybar-updates"
list_file="/tmp/waybar-updates-list"

# Função para verificar pacotes do sistema
verificar_pacotes() {
    checkupdates 2>/dev/null
}

# Função para verificar atualizações do Flatpak
verificar_flatpak() {
    flatpak remote-ls --updates 2>/dev/null | awk '{print $1 " -> " $3}'
}

# Verifica pacotes para atualização
pacotes=$(verificar_pacotes)
flatpaks=$(verificar_flatpak)

# Combina pacotes do sistema e Flatpak
if [ -n "$pacotes" ] || [ -n "$flatpaks" ]; then
    # Contagem total de atualizações
    total_updates=$(($(echo "$pacotes" | wc -l) + $(echo "$flatpaks" | wc -l)))
    echo "$total_updates" > "$updates_file"
    echo -e "$pacotes\n$flatpaks" > "$list_file"

    # Envia notificação
    resumo_pacotes=$(echo "$pacotes" | head -n 5 | awk '{print "• " $1 " -> " $2}')
    resumo_flatpaks=$(echo "$flatpaks" | head -n 5 | awk '{print "• " $1}')
    resumo_final="${resumo_pacotes}\n${resumo_flatpaks}"
    [ "$total_updates" -gt 10 ] && resumo_final="${resumo_final}\n• ..."

    notify-send -u low -t 5000 "Atualizações disponíveis" \
        "Há $total_updates atualizações pendentes:\n${resumo_final}"
else
    echo "0" > "$updates_file"
    echo "" > "$list_file"
    notify-send -u low -t 3000 "Sistema atualizado" "Nenhuma atualização disponível."
fi
