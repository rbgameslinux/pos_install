#!/bin/bash

# Lista as janelas abertas e exibe seus títulos
windows=$(hyprctl clients | grep -oP 'class:\s*\K.+' | awk '{print $1}')

# Exibe os títulos das janelas
output=""
for window in $windows; do
    output+="$window "
done

# Exibe a lista de janelas (se não houver janelas, retorna "Nenhuma janela")
echo "${output:-Nenhuma janela}"
