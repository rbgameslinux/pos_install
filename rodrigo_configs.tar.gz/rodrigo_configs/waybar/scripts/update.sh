#!/bin/bash

# Envia notificação inicial
dunstify -u low "Atualização iniciada" "Atualizando pacotes do Arch Linux e AUR..."

# Atualiza os pacotes do Arch e do AUR
sudo pacman -Syu --noconfirm
paru -Syu --noconfirm

# Envia notificação ao finalizar
dunstify -u normal "Atualização concluída" "Sistema totalmente atualizado!"
