#!/bin/bash
# Redireciona a saída do Cava para um arquivo ou dispositivo
cava > /dev/null 2>&1 &

