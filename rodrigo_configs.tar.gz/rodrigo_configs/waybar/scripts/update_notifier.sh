#!/bin/bash

# Verifica pacotes do Arch Linux e AUR usando yay
UPDATES=$(checkupdates 2> /dev/null | wc -l)  # Pacotes do Arch
AUR_UPDATES=$(paru -Qua 2> /dev/null | wc -l)  # Pacotes do AUR

# Notificação via Dunst
if [[ "$UPDATES" -gt 0 || "$AUR_UPDATES" -gt 0 ]]; then
    dunstify -u normal "Atualizações disponíveis" \
        "Pacotes do Arch: $UPDATES\nPacotes do AUR: $AUR_UPDATES"
fi

# Exibe ícone e contagem para a Waybar
if [[ "$UPDATES" -gt 0 || "$AUR_UPDATES" -gt 0 ]]; then
    echo "{\"text\": \" $UPDATES |  $AUR_UPDATES\", \"tooltip\": \"Arch: $UPDATES pacotes\nAUR: $AUR_UPDATES pacotes\"}"
else
    echo "{\"text\": \" 0 |  0\", \"tooltip\": \"Nenhuma atualização disponível\"}"
fi
