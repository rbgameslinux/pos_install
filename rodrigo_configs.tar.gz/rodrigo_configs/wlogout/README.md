# wlogout-theme

https://github.com/DreamMaoMao/wlogout-theme/assets/30348075/cd4a061f-0636-4740-abf8-0c1dfd352f0e

# install
```shell
mkdir -p ~/.config/wlogout
git clone https://github.com/DreamMaoMao/wlogout-theme.git
cd wlogout-theme
sed -i s#/home/user#$HOME#g sytle.css
sed -i s#/home/user#$HOME#g layout
cp ./* -r ~/.config/wlogout
```

# usage
```shell
wlogout -b 6
```

# refer from:
https://github.com/MrVivekRajan/Gruvminimal-Dots
